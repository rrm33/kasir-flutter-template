import 'package:kasirku/models/transaksi.dart';
import 'package:kasirku/models/user.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import '../models/barang.dart';
import '../models/detail_transaksi.dart';

class DatabaseHelper {
  static final DatabaseHelper instance = DatabaseHelper._init();
  static Database? _database;

  DatabaseHelper._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('kasir.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    await db.execute('''
    CREATE TABLE TOKO(
      id_toko INTEGER PRIMARY KEY AUTOINCREMENT,
      nama_toko TEXT,
      alamat TEXT,
      telepon TEXT
    )
    ''');

    await db.execute('''
CREATE TABLE user(
  id_user INTEGER PRIMARY KEY AUTOINCREMENT,
  nama_user TEXT,
  username TEXT UNIQUE,
  password TEXT,
  role TEXT
)
''');

    await db.insert('user', {
      'nama_user': 'Administrator',
      'username': 'admin',
      'password': 'admin123',
      'role': 'admin',
    });

    await db.execute('''
    CREATE TABLE BARANG(
      id_barang INTEGER PRIMARY KEY AUTOINCREMENT,
      kode_barcode TEXT,
      nama_barang TEXT,
      harga_beli INTEGER,
      harga_jual INTEGER,
      stok INTEGER
    )
    ''');

    await db.execute('''
    CREATE TABLE TRANSAKSI(
      id_transaksi INTEGER PRIMARY KEY AUTOINCREMENT,
      id_toko INTEGER,
      id_kasir INTEGER,
      tgl_transaksi TEXT,
      total_harga INTEGER,
      bayar INTEGER,
      kembalian INTEGER
    )
    ''');

    await db.execute('''
    CREATE TABLE DETAIL_TRANSAKSI(
      id_detail INTEGER PRIMARY KEY AUTOINCREMENT,
      id_transaksi INTEGER,
      id_barang INTEGER,
      jumlah INTEGER,
      harga_at_time INTEGER,
      subtotal INTEGER
    )
    ''');
  }

  Future<void> testInsert() async {
    final db = await instance.database;

    await db.insert('TOKO', {
      'nama_toko': 'Toko Rejeki Mengalir',
      'alamat': 'Tanggul, Jember',
      'telepon': '08123456789',
    });

    print("Insert TOKO berhasil");
  }

  ////////////////////////////////////////////////////////////////////////////////////
  // CRUD BARANG //
  ////////////////////////////////////////////////////////////////////////////////////

  Future<int> insertBarang(Barang barang) async {
    final db = await instance.database;

    return await db.insert('BARANG', barang.toMap());
  }

  Future<List<Barang>> getAllBarang() async {
    final db = await instance.database;

    final result = await db.query('BARANG', orderBy: 'nama_barang ASC');

    return result.map((map) => Barang.fromMap(map)).toList();
  }

  Future<int> deleteBarang(int id) async {
    final db = await instance.database;

    return await db.delete('BARANG', where: 'id_barang = ?', whereArgs: [id]);
  }

  Future<int> updateBarang(Barang barang) async {
    final db = await instance.database;

    return await db.update(
      'BARANG',
      barang.toMap(),
      where: 'id_barang = ?',
      whereArgs: [barang.idBarang],
    );
  }

  ////////////////////////////////////////////////////////////////////////////////////
  // CRUD USER //
  ////////////////////////////////////////////////////////////////////////////////////

  Future<int> insertUser(User user) async {
    final db = await database;
    return await db.insert('user', user.toMap());
  }

  Future<List<User>> getAllUser() async {
    final db = await database;
    final result = await db.query('user');

    return result.map((e) => User.fromMap(e)).toList();
  }

  Future<int> deleteUser(int id) async {
    final db = await database;
    return await db.delete('user', where: 'id_user = ?', whereArgs: [id]);
  }

  Future<int> updateUser(User user) async {
    final db = await database;
    return await db.update(
      'user',
      user.toMap(),
      where: 'id_user = ?',
      whereArgs: [user.idUser],
    );
  }

  ////////////////////////////////////////////////////////////////////////////////////
  // CRUD TRANSAKSI //
  ////////////////////////////////////////////////////////////////////////////////////

  Future<int> insertTransaksi(Transaksi transaksi) async {
    final db = await database;
    return await db.insert('transaksi', transaksi.toMap());
  }

  Future<List<Transaksi>> getAllTransaksi() async {
    final db = await database;
    final result = await db.query('transaksi', orderBy: 'tgl_transaksi DESC');

    return result.map((e) => Transaksi.fromMap(e)).toList();
  }

  Future<int> updateTransaksi(Transaksi transaksi) async {
    final db = await database;

    return await db.update(
      'transaksi',
      transaksi.toMap(),
      where: 'id_transaksi=?',
      whereArgs: [transaksi.idTransaksi],
    );
  }

  Future<int> deleteTransaksi(int id) async {
    final db = await database;

    return await db.delete(
      'transaksi',
      where: 'id_transaksi=?',
      whereArgs: [id],
    );
  }

  ////////////////////////////////////////////////////////////////////////////////////
  // CRUD DETAIL TRANSAKSI //
  ////////////////////////////////////////////////////////////////////////////////////

  Future<int> insertDetailTransaksi(DetailTransaksi detail) async {
    final db = await database;
    return await db.insert('detail_transaksi', detail.toMap());
  }

  Future<List<DetailTransaksi>> getDetailByTransaksi(int idTransaksi) async {
    final db = await database;
    final result = await db.query(
      'detail_transaksi',
      where: 'id_transaksi = ?',
      whereArgs: [idTransaksi],
    );
    return result.map((e) => DetailTransaksi.fromMap(e)).toList();
  }

  Future<int> deleteDetailTransaksi(int idTransaksi) async {
    final db = await database;
    return await db.delete(
      'detail_transaksi',
      where: 'id_transaksi = ?',
      whereArgs: [idTransaksi],
    );
  }

  // Get barang by barcode (untuk kasir scan)
  Future<Barang?> getBarangByBarcode(String barcode) async {
    final db = await database;
    final result = await db.query(
      'BARANG',
      where: 'kode_barcode = ?',
      whereArgs: [barcode],
    );
    if (result.isEmpty) return null;
    return Barang.fromMap(result.first);
  }

  // Update stok barang (kurangi saat transaksi)
  Future<int> updateStokBarang(int idBarang, int newStok) async {
    final db = await database;
    return await db.update(
      'BARANG',
      {'stok': newStok},
      where: 'id_barang = ?',
      whereArgs: [idBarang],
    );
  }

  // Get user by username
  Future<User?> getUserByUsername(String username) async {
    final db = await database;
    final result = await db.query(
      'user',
      where: 'username = ?',
      whereArgs: [username],
    );
    if (result.isEmpty) return null;
    return User.fromMap(result.first);
  }

  Future<Transaksi?> getTransaksiById(int id) async {
    final db = await database;
    final result = await db.query(
      'transaksi',
      where: 'id_transaksi = ?',
      whereArgs: [id],
    );
    if (result.isEmpty) return null;
    return Transaksi.fromMap(result.first);
  }
}
