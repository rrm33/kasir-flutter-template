class Transaksi {
  int? idTransaksi;
  int idToko;
  int idKasir;
  String tglTransaksi;
  double totalHarga;
  double bayar;
  double kembalian;

  Transaksi({
    this.idTransaksi,
    required this.idToko,
    required this.idKasir,
    required this.tglTransaksi,
    required this.totalHarga,
    required this.bayar,
    required this.kembalian,
  });

  Map<String, dynamic> toMap() {
    return {
      'id_transaksi': idTransaksi,
      'id_toko': idToko,
      'id_kasir': idKasir,
      'tgl_transaksi': tglTransaksi,
      'total_harga': totalHarga,
      'bayar': bayar,
      'kembalian': kembalian,
    };
  }

  factory Transaksi.fromMap(Map<String, dynamic> map) {
    return Transaksi(
      idTransaksi: map['id_transaksi'],
      idToko: map['id_toko'],
      idKasir: map['id_kasir'],
      tglTransaksi: map['tgl_transaksi'],
      totalHarga: (map['total_harga'] as num).toDouble(),
      bayar: (map['bayar'] as num).toDouble(),
      kembalian: (map['kembalian'] as num).toDouble(),
    );
  }
}