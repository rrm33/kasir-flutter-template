import 'package:flutter/material.dart';
import 'package:kasirku/database/database_helper.dart';
import 'package:kasirku/models/transaksi.dart';
import 'package:kasirku/models/detail_transaksi.dart';
import 'package:kasirku/models/user.dart';
import 'package:intl/intl.dart';
import 'package:print_bluetooth_thermal/print_bluetooth_thermal.dart';
import 'package:esc_pos_utils_plus/esc_pos_utils_plus.dart';

class StrukPage extends StatefulWidget {
  final int idTransaksi;

  const StrukPage({super.key, required this.idTransaksi});

  @override
  State<StrukPage> createState() => _StrukPageState();
}

class _StrukPageState extends State<StrukPage> {
  Transaksi? _transaksi;
  List<DetailTransaksi> _details = [];
  Map<int, String> _namaBarang = {};
  User? _kasir;
  bool isLoading = true;

  // Bluetooth printing state
  List<BluetoothInfo> _pairedDevices = [];
  bool _connected = false;
  String _info = "";

  @override
  void initState() {
    super.initState();
    _loadData();
    _initBluetooth();
  }

  Future<void> _loadData() async {
    final db = DatabaseHelper.instance;
    final transaksi = await db.getTransaksiById(widget.idTransaksi);
    
    if (transaksi == null) {
      setState(() => isLoading = false);
      return;
    }

    final details = await db.getDetailByTransaksi(transaksi.idTransaksi!);
    final kasir = await db.getAllUser().then((users) => 
        users.where((u) => u.idUser == transaksi.idKasir).firstOrNull);

    Map<int, String> namaBarangMap = {};
    for (var detail in details) {
      final barangAll = await db.getAllBarang();
      final found = barangAll.where((b) => b.idBarang == detail.idBarang).firstOrNull;
      if (found != null) {
        namaBarangMap[detail.idBarang] = found.namaBarang;
      }
    }

    setState(() {
      _transaksi = transaksi;
      _details = details;
      _kasir = kasir;
      _namaBarang = namaBarangMap;
      isLoading = false;
    });
  }

  Future<void> _initBluetooth() async {
    bool result = await PrintBluetoothThermal.bluetoothEnabled;
    if (result) {
      try {
        List<BluetoothInfo> listResult = await PrintBluetoothThermal.pairedBluetooths;
        setState(() {
          _pairedDevices = listResult;
        });
      } catch (e) {
        setState(() {
          _info = "Error getting paired devices: $e";
        });
      }
    } else {
      setState(() {
        _info = "Bluetooth is disabled.";
      });
    }
  }

  Future<void> _connectToPrinter(String macAddress) async {
    setState(() => _info = "Connecting...");
    try {
      final bool result = await PrintBluetoothThermal.connect(macPrinterAddress: macAddress);
      setState(() {
        _connected = result;
        _info = result ? "Connected to printer" : "Failed to connect";
      });
    } catch (e) {
      setState(() {
        _info = "Error connecting: $e";
        _connected = false;
      });
    }
  }

  Future<void> _printStruk() async {
    if (!_connected) {
      _showSnackBar("Connect ke printer terlebih dahulu!", Colors.red);
      return;
    }
    if (_transaksi == null) return;

    try {
      bool result = await PrintBluetoothThermal.connectionStatus;
      if (result) {
        List<int> bytes = await _getTicketBytes();
        await PrintBluetoothThermal.writeBytes(bytes);
        _showSnackBar("Mencetak struk...", Colors.green);
      } else {
        setState(() => _connected = false);
        _showSnackBar("Printer terputus", Colors.red);
      }
    } catch (e) {
      _showSnackBar("Error printing: $e", Colors.red);
    }
  }

  Future<List<int>> _getTicketBytes() async {
    List<int> bytes = [];
    try {
      final profile = await CapabilityProfile.load();
      final generator = Generator(PaperSize.mm58, profile);

      // Title
      bytes += generator.text("KASIRKU",
          styles: const PosStyles(
            align: PosAlign.center,
            height: PosTextSize.size2,
            width: PosTextSize.size2,
          ),
          linesAfter: 1);

      // Metadata
      bytes += generator.text("Tanggal : ${formatTanggal(_transaksi!.tglTransaksi)}",
          styles: const PosStyles(align: PosAlign.left));
      bytes += generator.text("Kasir   : ${_kasir?.namaUser ?? "Unknown"}",
          styles: const PosStyles(align: PosAlign.left));
      bytes += generator.text("No. Trx : ${_transaksi!.idTransaksi}",
          styles: const PosStyles(align: PosAlign.left));
      bytes += generator.hr();

      // Items
      for (var detail in _details) {
        final nama = _namaBarang[detail.idBarang] ?? "Barang";
        bytes += generator.text(nama, styles: const PosStyles(align: PosAlign.left));
        
        final qtyHarga = "${detail.jumlah} x ${detail.hargaAtTime}";
        final subtotal = "${detail.subtotal}";
        
        bytes += generator.row([
          PosColumn(
            text: qtyHarga,
            width: 6,
            styles: const PosStyles(align: PosAlign.left),
          ),
          PosColumn(
            text: subtotal,
            width: 6,
            styles: const PosStyles(align: PosAlign.right),
          ),
        ]);
      }

      bytes += generator.hr();

      // Totals
      bytes += generator.row([
        PosColumn(text: 'TOTAL', width: 6, styles: const PosStyles(align: PosAlign.left, bold: true)),
        PosColumn(
            text: _transaksi!.totalHarga.toInt().toString(),
            width: 6,
            styles: const PosStyles(align: PosAlign.right, bold: true)),
      ]);
      bytes += generator.row([
        PosColumn(text: 'BAYAR', width: 6, styles: const PosStyles(align: PosAlign.left)),
        PosColumn(text: _transaksi!.bayar.toInt().toString(), width: 6, styles: const PosStyles(align: PosAlign.right)),
      ]);
      bytes += generator.row([
        PosColumn(text: 'KEMBALI', width: 6, styles: const PosStyles(align: PosAlign.left)),
        PosColumn(
            text: _transaksi!.kembalian.toInt().toString(), width: 6, styles: const PosStyles(align: PosAlign.right)),
      ]);

      bytes += generator.feed(2);
      bytes += generator.text('Terima Kasih',
          styles: const PosStyles(align: PosAlign.center, bold: true), linesAfter: 2);
      
      // cut the paper
      bytes += generator.cut();
    } catch (e) {
      debugPrint("Error generating ticket bytes: $e");
    }
    return bytes;
  }

  String formatCurrency(double value) {
    return NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0).format(value);
  }

  String formatTanggal(String tgl) {
    try {
      final date = DateTime.parse(tgl);
      return DateFormat('dd MMM yyyy HH:mm', 'id_ID').format(date);
    } catch (e) {
      return tgl;
    }
  }

  void _showSnackBar(String text, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text), backgroundColor: color));
  }

  void _showPrinterDialog() {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Pilih Printer Bluetooth"),
          content: SizedBox(
            width: double.maxFinite,
            height: 300,
            child: _pairedDevices.isEmpty
                ? const Center(child: Text("Tidak ada perangkat bluetooth tersimpan."))
                : ListView.builder(
                    itemCount: _pairedDevices.length,
                    itemBuilder: (context, index) {
                      final device = _pairedDevices[index];
                      return ListTile(
                        leading: const Icon(Icons.print),
                        title: Text(device.name),
                        subtitle: Text(device.macAdress),
                        onTap: () {
                          Navigator.pop(context);
                          _connectToPrinter(device.macAdress);
                        },
                      );
                    },
                  ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Tutup"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    if (_transaksi == null) {
      return Scaffold(
        appBar: AppBar(title: const Text("Struk")),
        body: const Center(child: Text("Transaksi tidak ditemukan")),
      );
    }

    return Scaffold(
      backgroundColor: Colors.grey[200],
      appBar: AppBar(
        title: const Text("Preview Struk", style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.blueAccent,
        foregroundColor: Colors.white,
      ),
      body: Column(
        children: [
          // Bluetooth Status Banner
          Container(
            padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
            color: _connected ? Colors.green[100] : Colors.orange[100],
            child: Row(
              children: [
                Icon(
                  _connected ? Icons.bluetooth_connected : Icons.bluetooth_disabled,
                  color: _connected ? Colors.green[800] : Colors.orange[800],
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    _connected ? "Printer Terhubung" : (_info.isEmpty ? "Printer Belum Terhubung" : _info),
                    style: TextStyle(
                      color: _connected ? Colors.green[800] : Colors.orange[800],
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
                if (!_connected)
                  TextButton(
                    onPressed: _showPrinterDialog,
                    style: TextButton.styleFrom(
                      foregroundColor: Colors.white,
                      backgroundColor: Colors.orange[800],
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                    ),
                    child: const Text("Cari Printer", style: TextStyle(fontSize: 12)),
                  ),
              ],
            ),
          ),
          
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Center(
                child: Container(
                  width: 320, // Standard receipt paper width approximation
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.05),
                        blurRadius: 5,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const Text(
                        "KASIRKU",
                        style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, letterSpacing: 2),
                      ),
                      const SizedBox(height: 16),
                      // Meta Info
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text("Tanggal:", style: TextStyle(fontSize: 12)),
                          Text(formatTanggal(_transaksi!.tglTransaksi), style: const TextStyle(fontSize: 12)),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text("Kasir:", style: TextStyle(fontSize: 12)),
                          Text(_kasir?.namaUser ?? "Unknown", style: const TextStyle(fontSize: 12)),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text("No. Trx:", style: TextStyle(fontSize: 12)),
                          Text("${_transaksi!.idTransaksi}", style: const TextStyle(fontSize: 12)),
                        ],
                      ),
                      const Divider(thickness: 1, height: 24, color: Colors.black87),
                      
                      // Items
                      ..._details.map((detail) {
                        final nama = _namaBarang[detail.idBarang] ?? "Barang";
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 8.0),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(nama, style: const TextStyle(fontWeight: FontWeight.w600)),
                              Row(
                                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                children: [
                                  Text("${detail.jumlah} x ${formatCurrency(detail.hargaAtTime.toDouble())}"),
                                  Text(formatCurrency(detail.subtotal.toDouble())),
                                ],
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                      
                      const Divider(thickness: 1, height: 24, color: Colors.black87),
                      
                      // Totals
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text("TOTAL LAPORAN", style: TextStyle(fontWeight: FontWeight.bold)),
                          Text(formatCurrency(_transaksi!.totalHarga), style: const TextStyle(fontWeight: FontWeight.bold)),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text("BAYAR"),
                          Text(formatCurrency(_transaksi!.bayar)),
                        ],
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text("KEMBALIAN"),
                          Text(formatCurrency(_transaksi!.kembalian)),
                        ],
                      ),
                      
                      const SizedBox(height: 32),
                      const Text(
                        "Terima Kasih Atas Kunjungan Anda",
                        textAlign: TextAlign.center,
                        style: TextStyle(fontSize: 12, fontStyle: FontStyle.italic),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          
          // Action Buttons
          Container(
            padding: const EdgeInsets.all(16),
            decoration: const BoxDecoration(
              color: Colors.white,
              boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 4, offset: Offset(0, -2))],
            ),
            child: SafeArea(
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.pop(context),
                      style: OutlinedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        side: const BorderSide(color: Colors.blueAccent),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      child: const Text("KEMBALI", style: TextStyle(color: Colors.blueAccent, fontWeight: FontWeight.bold)),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: ElevatedButton.icon(
                      onPressed: _connected ? _printStruk : _showPrinterDialog,
                      icon: const Icon(Icons.print),
                      label: Text(_connected ? "CETAK" : "KONEK PRINTER"),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: _connected ? Colors.green : Colors.orange[800],
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
