import 'package:flutter/material.dart';
import 'package:kasirku/database/database_helper.dart';
import 'package:kasirku/models/transaksi.dart';
import 'package:kasirku/models/detail_transaksi.dart';
import 'package:kasirku/pages/transaksi/struk_page.dart';
import 'package:intl/intl.dart';

class DetailTransaksiPage extends StatefulWidget {
  final Transaksi transaksi;

  const DetailTransaksiPage({super.key, required this.transaksi});

  @override
  State<DetailTransaksiPage> createState() => _DetailTransaksiPageState();
}

class _DetailTransaksiPageState extends State<DetailTransaksiPage> {
  List<DetailTransaksi> _details = [];
  Map<int, String> _namaBarang = {};
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadDetails();
  }

  Future<void> _loadDetails() async {
    final details = await DatabaseHelper.instance.getDetailByTransaksi(
      widget.transaksi.idTransaksi!,
    );

    // Load nama barang untuk setiap detail
    Map<int, String> namaBarangMap = {};
    for (var detail in details) {
      final barang = await DatabaseHelper.instance.getAllBarang();
      final found = barang.where((b) => b.idBarang == detail.idBarang).firstOrNull;
      if (found != null) {
        namaBarangMap[detail.idBarang] = found.namaBarang;
      }
    }

    setState(() {
      _details = details;
      _namaBarang = namaBarangMap;
      isLoading = false;
    });
  }

  String formatCurrency(double value) {
    return NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0).format(value);
  }

  String formatTanggal(String tgl) {
    try {
      final date = DateTime.parse(tgl);
      return DateFormat('dd-MM-yyyy HH:mm', 'id_ID').format(date);
    } catch (e) {
      return tgl;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text("Detail Transaksi", style: TextStyle(fontWeight: FontWeight.bold)),
        elevation: 0,
        backgroundColor: Colors.blueAccent,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
            icon: const Icon(Icons.print),
            tooltip: "Cetak Struk",
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => StrukPage(idTransaksi: widget.transaksi.idTransaksi!),
                ),
              );
            },
          ),
        ],
      ),
      body: isLoading
          ? const Center(child: CircularProgressIndicator())
          : Column(
              children: [
                // Header Info Transaksi
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: const BoxDecoration(
                    color: Colors.blueAccent,
                    borderRadius: BorderRadius.only(
                      bottomLeft: Radius.circular(20),
                      bottomRight: Radius.circular(20),
                    ),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Total: ${formatCurrency(widget.transaksi.totalHarga)}",
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        "Tanggal: ${formatTanggal(widget.transaksi.tglTransaksi)}",
                        style: const TextStyle(color: Colors.white70),
                      ),
                      Text(
                        "Kasir ID: ${widget.transaksi.idKasir}",
                        style: const TextStyle(color: Colors.white70),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "Bayar: ${formatCurrency(widget.transaksi.bayar)}",
                            style: const TextStyle(color: Colors.white),
                          ),
                          Text(
                            "Kembalian: ${formatCurrency(widget.transaksi.kembalian)}",
                            style: const TextStyle(color: Colors.greenAccent),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),

                // List Item
                const Padding(
                  padding: EdgeInsets.all(16),
                  child: Text(
                    "Item Purchased",
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),

                Expanded(
                  child: _details.isEmpty
                      ? const Center(child: Text("Tidak ada detail"))
                      : ListView.builder(
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          itemCount: _details.length,
                          itemBuilder: (context, index) {
                            final detail = _details[index];
                            return Card(
                              margin: const EdgeInsets.only(bottom: 8),
                              child: ListTile(
                                leading: CircleAvatar(
                                  backgroundColor: Colors.blueAccent.withAlpha(25),
                                  child: Text(
                                    "${detail.jumlah}x",
                                    style: const TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: Colors.blueAccent,
                                    ),
                                  ),
                                ),
                                title: Text(
                                  _namaBarang[detail.idBarang] ?? "Barang ID: ${detail.idBarang}",
                                  style: const TextStyle(fontWeight: FontWeight.bold),
                                ),
                                subtitle: Text(
                                  "${formatCurrency(detail.hargaAtTime.toDouble())} x ${detail.jumlah}",
                                ),
                                trailing: Text(
                                  formatCurrency(detail.subtotal.toDouble()),
                                  style: const TextStyle(
                                    fontWeight: FontWeight.bold,
                                    color: Colors.green,
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
    );
  }
}

