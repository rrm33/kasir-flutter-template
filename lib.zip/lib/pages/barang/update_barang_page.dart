import 'package:flutter/material.dart';
import '../../database/database_helper.dart';
import '../../models/barang.dart';

class UpdateBarangPage extends StatefulWidget {
  final Barang barang;

  const UpdateBarangPage({super.key, required this.barang});

  @override
  State<UpdateBarangPage> createState() => _UpdateBarangPageState();
}

class _UpdateBarangPageState extends State<UpdateBarangPage> {
  final _formKey = GlobalKey<FormState>();

  late TextEditingController kodeController;
  late TextEditingController namaController;
  late TextEditingController hargaBeliController;
  late TextEditingController hargaJualController;
  late TextEditingController stokController;

  @override
  void initState() {
    super.initState();

    kodeController =
        TextEditingController(text: widget.barang.kodeBarcode);
    namaController =
        TextEditingController(text: widget.barang.namaBarang);
    hargaBeliController =
        TextEditingController(text: widget.barang.hargaBeli.toString());
    hargaJualController =
        TextEditingController(text: widget.barang.hargaJual.toString());
    stokController =
        TextEditingController(text: widget.barang.stok.toString());
  }

  Future<void> _updateBarang() async {
    if (_formKey.currentState!.validate()) {
      final barangUpdate = Barang(
        idBarang: widget.barang.idBarang,
        kodeBarcode: kodeController.text,
        namaBarang: namaController.text,
        hargaBeli: int.parse(hargaBeliController.text),
        hargaJual: int.parse(hargaJualController.text),
        stok: int.parse(stokController.text),
      );

      await DatabaseHelper.instance.updateBarang(barangUpdate);

      if (!mounted) return;
      Navigator.pop(context, true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Update Barang")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: kodeController,
                readOnly: true,
                decoration:
                    const InputDecoration(labelText: "Kode Barcode"),
              ),
              TextFormField(
                controller: namaController,
                decoration:
                    const InputDecoration(labelText: "Nama Barang"),
                validator: (value) =>
                    value!.isEmpty ? "Tidak boleh kosong" : null,
              ),
              TextFormField(
                controller: hargaBeliController,
                keyboardType: TextInputType.number,
                decoration:
                    const InputDecoration(labelText: "Harga Beli"),
                validator: (value) =>
                    value!.isEmpty ? "Tidak boleh kosong" : null,
              ),
              TextFormField(
                controller: hargaJualController,
                keyboardType: TextInputType.number,
                decoration:
                    const InputDecoration(labelText: "Harga Jual"),
                validator: (value) =>
                    value!.isEmpty ? "Tidak boleh kosong" : null,
              ),
              TextFormField(
                controller: stokController,
                keyboardType: TextInputType.number,
                decoration:
                    const InputDecoration(labelText: "Stok"),
                validator: (value) =>
                    value!.isEmpty ? "Tidak boleh kosong" : null,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _updateBarang,
                child: const Text("Update"),
              )
            ],
          ),
        ),
      ),
    );
  }
}