import 'package:flutter/material.dart';
import '../../database/database_helper.dart';
import '../../models/barang.dart';

class TambahBarangPage extends StatefulWidget {
  const TambahBarangPage({super.key});

  @override
  State<TambahBarangPage> createState() => _TambahBarangPageState();
}

class _TambahBarangPageState extends State<TambahBarangPage> {
  final _formKey = GlobalKey<FormState>();

  final kodeController = TextEditingController();
  final namaController = TextEditingController();
  final hargaBeliController = TextEditingController();
  final hargaJualController = TextEditingController();
  final stokController = TextEditingController();

  Future<void> _simpanBarang() async {
    if (_formKey.currentState!.validate()) {
      final barang = Barang(
        kodeBarcode: kodeController.text,
        namaBarang: namaController.text,
        hargaBeli: int.parse(hargaBeliController.text),
        hargaJual: int.parse(hargaJualController.text),
        stok: int.parse(stokController.text),
      );

      await DatabaseHelper.instance.insertBarang(barang);

      if (!mounted) return;
      Navigator.pop(context, true); // kirim sinyal refresh
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Tambah Barang")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: kodeController,
                decoration: const InputDecoration(labelText: "Kode Barcode"),
                validator: (value) =>
                    value!.isEmpty ? "Tidak boleh kosong" : null,
              ),
              TextFormField(
                controller: namaController,
                decoration: const InputDecoration(labelText: "Nama Barang"),
                validator: (value) =>
                    value!.isEmpty ? "Tidak boleh kosong" : null,
              ),
              TextFormField(
                controller: hargaBeliController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: "Harga Beli"),
                validator: (value) =>
                    value!.isEmpty ? "Tidak boleh kosong" : null,
              ),
              TextFormField(
                controller: hargaJualController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: "Harga Jual"),
                validator: (value) =>
                    value!.isEmpty ? "Tidak boleh kosong" : null,
              ),
              TextFormField(
                controller: stokController,
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(labelText: "Stok"),
                validator: (value) =>
                    value!.isEmpty ? "Tidak boleh kosong" : null,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _simpanBarang,
                child: const Text("Simpan"),
              )
            ],
          ),
        ),
      ),
    );
  }
}